Database is provided.

User Login:
username: user
password: user

Admin Login:
username: admin
password: admin