<!-- Footer Section Starts -->
<div class="footer">
    <div class="wrapper">
        
        <p class="text-center">
            Copyright © 2080 <a href="../index.php" style="color: #a0c0fd;" target="_blank">Belbari Municipality</a> All Rights Reserved.
        </p>
    </div>
</div>
<!-- Footer Section Ends -->
</body>

</html>